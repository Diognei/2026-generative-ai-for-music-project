# 1. Análise block_size música multitrack

**Conversation ID:** `8d2f5c72-a3c8-4484-a142-c19f013f2a71`  
**Messages:** 8 (user: 4, assistant: 4)  
**Part:** 3/4 (messages 5–6)  

---

## Message 5 — *?*

### 👤 User

Por restrição de tempo e GPU, o ablation foi rodado por 30 épocas em um subset determinístico de 20% do treino do LMD-clean (2.757 peças, seed=42), validado em 100% do conjunto de validação (1.723 peças), com batch efetivo de 128 (16×8 gradient accumulation) e stride proporcional (block_size / 2).

Atue como um revisor rigoroso: quais variáveis de confusão ou efeitos colaterais esse protocolo introduz? Em particular, como o stride proporcional altera o número de passos de gradiente por época entre ctx_256 e ctx_1024, e isso pode explicar instabilidade ou divergência tardia no treinamento de ctx_256?


---

## Message 6 — *?*

<details><summary>💭 <em>thinking</em></summary>

```
The user wants a rigorous review of their ablation protocol. Let me carefully analyze the confounds.

Setup:
- 30 epochs on deterministic 20% subset (2757 pieces), seed=42
- Validation on 100% of val (1723 pieces)
- Effective batch 128 (16×8 grad accumulation)
- Stride proportional (block_size/2)

So for ctx_256: stride=128; for ctx_1024: stride=512.

Number of training windows per piece depends on length. If a piece has length L tokens, number of windows ≈ (L - block_size) / stride + 1. With stride = block_size/2, windows per piece ≈ 2L/block_size (roughly).

Wait, but they say "batch efetivo de 128 (16×8)" — so 16 per GPU × 8 grad accumulation = 128 sequences per step.

Number of steps per epoch = total_windows / 128.

Total windows ∝ N_pieces × L_avg / block_size (approximately, with stride=block_size/2 → 2× windows per piece vs stride=block_size, but per block_size).

Actually let's compute: for block_size B, stride B/2, a piece of length L gives approximately (L - B)/(B/2) + 1 ≈ 2L/B windows (for L >> B). So windows per epoch ∝ 1/B. With B=256: 4× more windows than B=1024. So steps per epoch: 4× more.

30 epochs: ctx_256 does 4× more gradient steps than ctx_1024. That's 30×N_256 steps vs 30×N_1024 = 30×N_256/4 steps. So ctx_256 does ~4× more optimizer steps → 4× more tokens seen? Wait, tokens per step: 128 × B. So tokens per step for 256 is 128×256=32768; for 1024 it's 128×1024=131072. Steps per epoch 4× more for 256. Tokens per epoch: windows × B = (2L/B) × B = 2L — independent of B! So tokens seen per epoch is the same. Good.

So tokens seen per epoch is invariant to B (with stride=B/2). But number of gradient steps varies 4×. So:
- ctx_256: 4× more steps, each with 1/4 the tokens (in tokens-per-step terms), same total tokens
- ctx_1024: 1/4 steps, each with 4× tokens

So the ablation is fixed in tokens per epoch, but not in steps. This means:
1. ctx_256 has 4× more optimizer updates at lr=3e-4. Higher effective learning rate per token.
2. ctx_1024 has 4× larger batch (in tokens) — more stable gradient estimates, lower gradient noise.

This is a classic confound. With lr=3e-4 and AdamW, 4× more steps at same lr means much more aggressive optimization in terms of parameter movement per token.

Also, 30 epochs × 4× steps for 256 means it goes through the cosine schedule (if any) 4× faster in token terms... wait no, if schedule is in epochs, then it's aligned in epochs. But if schedule is in steps (typical), then ctx_256 completes its schedule in 1/4 wall-clock (in steps), which means it effectively has a much shorter schedule. Actually if schedule is in steps and set to total steps for each run, then ctx_256's schedule spans 4× more steps but same epochs — so LR decays over the same number of epochs. So in token terms, LR schedule is the same. But gradient noise per step is 4× lower for 1024.

Key point: with fixed lr and AdamW, gradient noise scale matters. Smaller batches (in tokens) → noisier gradients → with same lr, more likely to have instability at high lr. Actually more steps at smaller batch can act like higher effective lr and cause instability/divergence late.

Wait, let's think about "divergence tardia" specifically. They ask: can the stride proportional explain instability or late divergence in ctx_256?

Possibilities:
1. **4× more steps**: at lr=3e-4 with AdamW, 4× more updates = 4× more parameter movement per token (in expectation, ignoring schedule). If schedule is in steps and each run has its own total, then no. But if schedule is fixed (e.g., constant lr), then 4× more steps → more chance for divergence.

2. **Gradient noise from smaller per-step batch**: 16 sequences × 256 tokens = 4096 tokens per micro-batch vs 16×1024 = 16384. With grad accumulation 8, effective batch tokens: 32768 vs 131072. Larger gradient noise for 256 → at fixed lr, more likely to hit instability boundaries. Classic: higher gradient noise + same lr → late training instability.

3. **Boundary effects**: 4× more windows per epoch means 4× more boundary tokens per token seen. Each window starts cold (no context). With 30 epochs, the model sees more "cold start" patterns. This creates a training signal bias: it's trained to predict from cold context more often, which is a distribution shift from continuous generation. But this is not instability per se.

4. **Position embedding usage**: all positions 0-255 are used heavily; positions get more gradient signal per position (4× more). This might lead to PE overfitting at short positions? Unclear.

5. **Validation is full-set and fixed** — that's good, but validation CE will be at fixed contexts. However, validation with stride? If validation uses full pieces with sliding windows, the boundary fraction differs: 256 has 4× more boundary tokens → validation CE artificially penalized for 256. Actually they said "validado em 100% do conjunto de validação" — but with what stride/window? If they use the same stride proportional, then val CE also has 4× more boundary tokens for 256. This creates a systematic disadvantage for 256 in CE not due to modeling capacity.

6. **20% subset vs 100% val**: distribution mismatch if subset isn't stratified by composer/style. LMD-clean is known to have composer/album leakage. If 20% subset is by piece (not by composer), then val pieces may have composers seen in train (leakage) or not. With only 20% of pieces, the chance of composer overlap decreases, but also the model sees much less data. 2757 pieces is small — 30 epochs on this = high overfitting risk, especially for 1024 which has more capacity per sequence (though fewer steps).

Actually important: with 20% data and 30 epochs, we're in a regime where the model may overfit. The 256 model does 4× more steps → more overfitting per epoch? Wait, tokens per epoch same, so total tokens seen is the same (30 × 2L×N). Overfitting depends on total tokens and model capacity, not steps. But 4× more steps at same lr → more parameter updates → potentially more overfitting or memorization. Adam with fixed lr over more steps → more drift.

7. **Gradient accumulation mismatch**: 16×8 = 128 sequences. For 1024, that's 131k tokens per step — quite large. For 256, 32k tokens per step. The effective batch size in tokens differs 4×. This changes optimal lr: typically lr should scale with sqrt(batch) or linearly. With fixed lr, the 256 model is effectively at higher lr per token. This is the core confound.

8. **Scheduler in epochs vs steps**: if scheduler is step-based and set to total steps of each run, then LR trajectory in epochs is identical. If set to a fixed number (e.g., based on 1024 run), then 256 run completes its schedule 4× earlier in epochs... They didn't specify. Need to flag.

9. **Dropout and weight decay**: weight decay is applied per step. 4× more steps → 4× more weight decay per token. This is a real effect! AdamW decoupled weight decay: each step applies wd × lr × w. 4× more steps → 4× more decay per token. So ctx_256 is effectively more regularized (more weight decay) per token. But also more updates could counter. Actually with the same schedule, total weight decay applied is 4× for 256. That's a confound.

10. **Data ordering / shuffling**: with different number of windows, shuffling order differs. Same seed but different sequence lengths → effectively different shuffling. Not fatal but worth noting.

11. **"Divergência tardia" for 256**: several mechanisms:
   - Gradient noise + high lr: small token batch → noisy gradients → at late training when curvature is high, can bounce/explode.
   - More steps means the model has gone further; if there's a sharp loss landscape feature, it might hit it.
   - No LR warmup mentioned? With 4× steps, warmup in steps means 4× shorter in tokens for 256... wait, if warmup is fixed steps, for 256 it's 1/4 of epoch time vs 1024. Could be an issue if warmup is too short.
   - Boundary distribution shift: model over-fits to cold-start patterns; when cold starts dominate but val is evaluated differently, or when internal representations drift.
   - The 256 model may be more prone to representing local patterns with high confidence; with more steps it sharpens. Late divergence could be attention entropy collapse or logit explosion.

12. **Validation set fixed at 100% but train 20%**: risk of val leakage if LMD-clean has near-duplicates or same-composer pieces. Since train is 20% random subset (by piece, seed 42), many val pieces' composers may appear in train → inflated val performance, and unequal across B? Not directly, but the model with more steps may memorize composer-specific patterns more.

13. **Epoch-based stopping with different step counts**: early stopping or "best val" checkpointing would be biased because 256 has 4× more checkpoints per epoch. If they pick best val at epoch granularity, 256 gets 4× more evaluation points... wait no, epochs are same count. Checkpoints at epoch boundaries: same number. But within epoch, 256 is 4× more trained. So at epoch e, 256 has seen 4× more steps. The comparison at "epoch 30" is not fair in steps. But in tokens, they're equal. So it depends on what matters: tokens or steps. For final model quality, tokens seen matters more, but optimizer state dynamics matter too.

Let me also address: does stride proportional change steps per epoch? Yes:
- Windows per piece for B: ~2L/B
- Total windows per epoch: ~2 × total_tokens / B (total_tokens = sum of L)
- Steps per epoch = total_windows / 128 = 2 × total_tokens / (B × 128)
- So steps per epoch ∝ 1/B. ctx_256 has 4× steps per epoch vs ctx_1024.

Total steps over 30 epochs: 30 × 2 × total_tokens / (B × 128). So 4× more for 256.

Tokens per epoch: steps × 128 × B = 2 × total_tokens — same for both. Good, so tokens seen per epoch is invariant. This is actually a *feature* of stride=B/2 (windows overlap 50%, so each token appears in ~2 windows on average). So tokens seen per epoch = 2× total corpus tokens, independent of B.

So the confound: **fixed lr + fixed weight decay + 4× more optimizer steps = 4× higher effective learning rate and 4× more weight decay per token for ctx_256**.

This is precisely the mechanism that could explain late instability in ctx_256: with AdamW at 3e-4, doing 4× more updates per token is like training with 4× higher lr (roughly), which can cause late-training divergence, especially with noisy gradients from smaller token batches (though smaller batch per step: 32k vs 131k tokens — actually 256 has smaller batch per step, so *more* gradient noise, which can also cause instability at high lr).

Wait, let me be careful: gradient noise scale. With smaller batch, gradient estimate is noisier. At fixed lr, noisier gradients → more likely to bounce around. So 256 has: smaller batch (noisier) + more steps (more updates) → doubly prone to instability. This is a strong hypothesis for late divergence.

Also: the loss curvature — after many steps, the model may enter a region where the effective lr (in parameter space) is too high for the local curvature, causing oscillation or divergence. This is common with Adam and fixed lr over long training.

Additional subtle effects:

14. **The 50% overlap (stride B/2) doubles the effective epoch size** and means each token is seen twice per epoch. This is fine but means "30 epochs" = 60 passes equivalent. With 20% subset, that's like 12 full-data epochs. Reasonable but data-limited.

15. **Short-window validation bias**: If val uses the same stride-proportional windowing, val CE for 256 is computed over 4× more windows, with 4× higher boundary fraction. Boundary tokens have higher loss → val CE biased upward for 256. To fix: evaluate val CE on full pieces with a single pass (or equalize boundary fraction by masking first k tokens per window). They said "validado em 100% do conjunto de validação" — ambiguous whether per-window or full-piece. If per-window with stride B/2, big bias. Must flag.

16. **Composer/album leakage in LMD-clean**: LMD-clean has known metadata (composer, album). A 20% random piece split leaves many composers in both train and val (if composers have multiple pieces). This inflates val and may interact with training duration: 256 does more steps → more memorization of seen composers → possibly *higher* val on leaked composers, masking generalization gap. Or if memorization causes overconfidence, could hurt. Flag as risk.

17. **Determinism and seed**: same seed for subset, but different shuffle order due to different window counts. Also, with 4× more steps, random augmentations (if any) and dropout masks differ in aggregate. Not fatal but means "same seed" doesn't control for training trajectory.

18. **Batch norm / layernorm**: pre-norm Transformer, so no BN running stats issues. Good.

19. **Gradient clipping**: if used, 4× more steps → more clips per token. If not used, 256 more prone to spikes. Late divergence could be gradient explosion; need to check grad norm curves. Strongly recommend logging grad norm per step; if 256 spikes late, that's the smoking gun.

20. **"Divergência tardia" alternatives**: 
   - Attention entropy collapse (heads become deterministic) — more likely with more updates
   - Logit scale growth (final linear layer norm grows) — common late-training issue, more steps → more growth
   - PE overfitting at specific positions
   - Loss landscape sharpness (edge of stability) — more steps at fixed lr can push into sharp region

Let me structure the answer.

Structure:
1. Direct answer to the stride question with the math (steps/epoch ∝ 1/B, tokens/epoch invariant).
2. The core confound: effective lr and weight decay per token scale with steps.
3. Mechanisms for late instability in ctx_256 (gradient noise, more updates, edge of stability, grad norm spikes).
4. Other confounds: validation windowing bias, LMD-clean composer leakage, epoch-based stopping, scheduler ambiguity, dropout mask aggregate, data ordering.
5. What to check / how to diagnose (grad norm, logit scale, attention entropy, loss vs step and vs token, per-position loss).
6. Recommended fixes/minimal re-runs to de-confound.

I should be rigorous and specific. Let me write in Portuguese (user wrote in Portuguese).

Let me compute concrete numbers for the math.

Suppose total tokens in 20% subset = T (across all pieces). With stride B/2:
- Windows per piece ≈ 2L/B (for L >> B)
- Total windows per epoch W(B) ≈ 2T/B
- Steps per epoch = W/128 = T/(64B)
- For B=256: T/16384 steps/epoch
- For B=1024: T/65536 steps/epoch
- Ratio: 4×.

Tokens per step = 128×B. Tokens per epoch = steps × 128B = (T/(64B)) × 128B = 2T. Invariant. Good.

If T = say 2757 pieces × avg 5000 tokens = ~14M tokens. Then:
- B=256: steps/epoch ≈ 14e6/16384 ≈ 854 steps/epoch; 30 epochs ≈ 25,600 steps.
- B=1024: steps/epoch ≈ 14e6/65536 ≈ 213 steps/epoch; 30 epochs ≈ 6,400 steps.
- Tokens/epoch ≈ 28M; total ≈ 840M tokens both.

25,600 steps at lr=3e-4 with AdamW — plenty of steps to converge and potentially overfit/divergence. 6,400 steps is on the low side for 1024.

At 6,400 steps for 1024, the model may be undertrained (not converged), so "convergence speed" comparison is confounded: 256 may look better early because it has more updates, but 1024 hasn't finished.

Also 25,600 steps × 30 epochs... wait 854×30 = 25,620, yes.

Actually if avg piece is shorter, say 2000 tokens, T=5.5M, then B=256: 336 steps/epoch, 10k steps total; B=1024: 84 steps/epoch, 2.5k steps total. 1024 with 2.5k steps is quite undertrained. The final comparison would be unfair to 1024.

So a key confound: **at fixed epochs, ctx_1024 may be undertrained (too few steps) while ctx_256 is well-trained or overfit**. This biases the CE comparison in favor of 256, or if 256 diverges, against it.

Also: "divergência tardia" in 256 — with 25k steps at fixed lr, late training could hit instability. Common signature: val loss decreases then suddenly increases, grad norm spikes, or train loss decreases while val increases (overfitting). Need to distinguish divergence (train also worsens) from overfitting (train improves, val worsens). The user says "divergência tardia" suggesting train loss increases. Mechanisms:
- Too high effective lr after many steps
- Gradient noise
- Loss landscape sharpness
- Attention collapse

Let me also note: stride proportional means that for 256, the same token is seen in 2 windows per epoch (50% overlap). For 1024 also 50% overlap. Same overlap ratio. So no differential overlap effect. Good.

Actually wait: with stride B/2, each token appears in 2 windows on average only if L >> B. For pieces comparable to B, boundary effects dominate. For 1024, many pieces might be < 1024 tokens, meaning single window per piece (no stride effect) or few windows. For 256, same piece gives many windows. This changes the *effective number of examples* and the diversity of contexts. For short pieces, 1024 wastes padding. Flag: check piece length distribution; if many pieces < 1024, ctx_1024 has severe padding and reduced effective data, while ctx_256 has full utilization. This is a big confound for LMD-clean where pieces vary a lot.

That's an important point! LMD-clean pieces range from very short to very long. With B=1024 and stride 512, short pieces (<1024) get padded, and the number of windows is small. With B=256, even short pieces yield multiple windows. So the effective data utilization differs. This can explain different convergence and even instability (padding masks, fewer updates for 1024).

Let me also mention: 30 epochs on 20% = limited. If 1024 gets 4× fewer steps, it's likely undertrained, so its val CE may be higher not because of context but because of underfitting. Conversely, 256 with 4× more steps may overfit (or diverge). The comparison conflates context length with optimization budget.

How to de-confound without re-running everything:
- Log step-wise train/val loss and grad norm; plot vs step and vs tokens.
- Check if 1024 is still improving at epoch 30 (undertrained) and if 256 diverges late (grad norm spike).
- Post-hoc: compare at equal tokens, not equal epochs; or compare best val checkpoint.
- Evaluate val CE with boundary-masked loss to remove windowing bias.
- Check per-piece-length stratified metrics to see if padding/stride effects dominate.

Now let me also address "variáveis de confusão ou efeitos colaterais" comprehensively:

A. Step count / optimization budget (main).
B. Effective learning rate and weight decay per token (scales with steps).
C. Gradient noise / batch size in tokens (smaller for 256).
D. Padding and data utilization for short pieces (worse for 1024).
E. Validation windowing bias (more boundary tokens for 256 if using stride B/2 in val).
F. LMD-clean composer/album leakage in 20% subset + 100% val.
G. Overfitting vs divergence ambiguity with 30 epochs on small subset.
H. Scheduler ambiguity (steps vs epochs; warmup).
I. Data ordering / shuffle with different window counts.
J. Dropout mask aggregate / augmentation aggregate differences.
K. Early stopping / checkpoint selection granularity (same epochs, different steps).
L. Statistical: single seed, no variance estimates.

For the late divergence specifically, I should give the mechanisms and the diagnostic.

Let me write a thorough, well-organized review. Use tables where helpful. Be rigorous but concise enough. The user wants a "revisor rigoroso" tone.

I'll structure:
1. Resposta direta: matemática do stride e steps/epoch.
2. O confound central: orçamento em passos vs tokens.
3. Mecanismos de instabilidade tardia em ctx_256 (com explicação e como diagnosticar).
4. Outros confounds (validação, dados, padding, scheduler, etc.).
5. Diagnósticos mínimos para resgatar o experimento.
6. Recomendações de re-run mínimo (se possível).

Let me write in Portuguese, technical and precise.

Numbers: I'll parameterize with T (total tokens) but also give illustrative numbers.

For LMD-clean: ~176k pieces total? Actually LMD-clean has ~176k? No, LMD-full has ~176k, LMD-clean is a cleaner subset. Let me not assume. 20% = 2757 pieces means full train ≈ 13,785 pieces. Val 1723. That seems small for LMD-clean (which I think has more). Maybe they're using a filtered subset. Anyway, 2757 pieces, avg maybe 2000-5000 tokens. T ≈ 5-15M tokens.

Let me use T as variable and give formula, plus example with T=10M.

Steps/epoch(B) = T/(64B).
- B=256: 610 steps/epoch (if T=10M); 30 epochs = 18,300 steps.
- B=1024: 152 steps/epoch; 30 epochs = 4,560 steps.

1024 with 4,560 steps at lr 3e-4 — undertrained for a 6-layer model? Probably yes, especially with large batch (131k tokens/step). Actually 4,560 steps × 131k tokens = 600M tokens seen. That's a lot of tokens actually. Hmm. But steps matter for optimization. 4.5k steps is low for Adam convergence. 18k is more typical. So likely 1024 is undertrained in steps.

But also 600M tokens is substantial. With a small model (6 layers, d=256, ~10M params?), 600M tokens is plenty in token terms. So the model might be okay but not fully optimized. Hmm. The distinction: 1024 has larger batch per step (131k tokens), so 4.5k steps × 131k = 600M tokens; 256 has 18k steps × 32k = 600M tokens. Same tokens. But optimization: 18k Adam steps vs 4.5k. With lr 3e-4, 4.5k steps might be insufficient for full convergence, especially with warmup and cosine decay over 4.5k steps. Actually if cosine decay is over 4.5k steps, it reaches low lr at the end — might be okay. If cosine is over 18k steps but training stops at 4.5k... but each run has its own schedule presumably. Hmm.

The main point: step counts differ 4×, so optimizer dynamics differ. Whether 1024 is undertrained depends on schedule. Flag it.

For instability in 256: 18k steps at fixed lr, with gradient noise from 32k-token batches. Adam with lr 3e-4 and weight decay — after 18k steps, could drift. Especially if no grad clipping. Need to check.

OK let me also think about: "stride proporcional (block_size / 2)" — for 256, stride 128; for 1024, stride 512. Number of windows per piece for length L: floor((L - B)/stride) + 1 = floor((L-B)/(B/2)) + 1 ≈ 2(L-B)/B + 1. For L >> B, ≈ 2L/B.

So windows ∝ 1/B. Steps ∝ 1/B. Confirmed 4× ratio.

Also note: total tokens processed per epoch = windows × B ≈ 2L per piece — independent of B. So "epoch" is defined in a B-invariant way in terms of tokens. Good. But steps differ.

The 50% overlap means each token is seen ~2× per epoch regardless of B. So "30 epochs" = 60 token-passes. With 20% data, that's like 12 full-data epochs in token terms. Still limited data.

OK, writing the answer now.

I'll also mention: the batch size in *sequences* is fixed at 128, but in *tokens* it's 128B, so 4× different. This is a classic "batch size confound" for lr scaling. If lr was tuned for one batch size, it's suboptimal for the other. With fixed lr=3e-4, likely tuned for something; the 4× difference means one is at wrong lr. Standard practice: scale lr with sqrt(batch_tokens) or linear. So 256 should use lr ~3e-4/2 = 1.5e-4 (sqrt scaling) or 0.75e-4 (linear) to match 1024. Or vice versa. This alone could explain instability in 256 (lr too high for its effective batch) and slow convergence in 1024 (lr too low for its larger batch... actually larger batch usually wants higher lr).

Wait: larger batch → lower gradient noise → can use higher lr. So 1024 with 131k tokens could use higher lr than 3e-4; at 3e-4 it's conservative → slower convergence but stable. 256 with 32k tokens at 3e-4 is relatively aggressive → faster but riskier. This matches the hypothesis: 256 converges faster but may diverge late; 1024 converges slower but stable. 

Let me finalize. I'll write a comprehensive review.

Also mention: validation on 100% val (1723 pieces) — good for low variance, but if val windowing uses stride B/2, bias. And if val pieces have composers in train (20% subset), leakage. Also 1723 val pieces with 100% evaluation is expensive per epoch — but fine.

Another: "30 épocas" with different steps/epoch — the number of *validation evaluations* is 30 for both (if per epoch). But 256 has 4× more training per evaluation → coarser monitoring; divergence might be missed between epoch boundaries. Actually 256 does 610 steps between evals, 1024 does 152. So 256's divergence could be more abrupt between evals.

Also: if "divergência tardia" is detected, when did it start? Need step-level logging.

I think I have enough. Let me write.

Format: use headers, some math, tables, bullet lists. Keep it rigorous. Length: substantial but organized. Maybe 800-1200 words in Portuguese. Given the technical depth, I'll aim for thorough but not bloated.

I'll include a small table for steps/epoch.

Let me draft.

---

One more: "divergência tardia" could also be due to **PE overfitting**: with 256, positions 0-255 get 4× more gradient updates. The PE embedding might overfit to specific positions, especially early positions (boundary), causing weird behavior. Not classic divergence but instability. Mention briefly.

Also **attention entropy collapse** with more steps: heads become peaked, losing diversity, leading to worse generalization. Diagnostic: measure entropy.

Also **logit norm growth**: final linear layer weights grow, logits explode, softmax saturates, gradients vanish or explode. Common late-training. More steps → more growth. Diagnostic: monitor ||W_out|| and max logit.

OK writing.

I'll answer in Portuguese as the user is writing in Portuguese.
```

</details>

### 🤖 Assistant

# Revisão rigorosa do protocolo

## 1. A matemática do stride proporcional — e o confound que ela cria

Com `stride = block_size/2`, para uma peça de comprimento `L >> B`, o número de janelas é

```
W(B) ≈ (L − B)/(B/2) + 1  ≈  2L/B
```

Logo, por época:

| grandeza | depende de B | ctx_256 | ctx_1024 | razão |
|---|---|---|---|---|
| janelas/época | ∝ 1/B | 4× | 1× | **4×** |
| **passos de gradiente/época** = W/128 | ∝ 1/B | 4× | 1× | **4×** |
| tokens/passo = 128·B | ∝ B | 1× | 4× | 4× |
| **tokens vistos/época** = passos·128·B | **invariante** | 2T | 2T | **1×** |

Onde `T` = total de tokens do subset. **O stride proporcional torna “época” invariante em tokens, mas NÃO em passos.** Em 30 épocas:

- ctx_256: **~4× mais passos de AdamW** que ctx_1024 (ex.: com T≈10M tokens, ~18k vs ~4,5k passos).
- Ambos veem o mesmo número de tokens (≈60 passes sobre o subset, pois overlap de 50%).

Esse é o confound central e ele **não é cosmético**: com `lr=3e-4` e AdamW fixos, o modelo de 256 recebe 4× mais atualizações por token — ou seja, opera com **learning rate efetivo ~4× maior por token** e **weight decay acumulado ~4× maior por token** (AdamW aplica `wd·lr·w` a cada passo). Além disso, o batch efetivo *em tokens* é 4× menor (32k vs 131k), portanto o gradiente é 4× mais ruidoso. A combinação “lr efetivo alto + gradiente ruidoso” é exatamente a receita clássica de **instabilidade tardia**.

---

## 2. Por que ctx_256 pode divergir tarde — mecanismos concretos

Sua pergunta é se o stride proporcional pode explicar a divergência tardia do 256. **Sim, e por pelo menos cinco vias independentes, todas amplificadas pelos 4× mais passos:**

1. **Edge of stability / lr efetivo alto.** Com 4× mais passos no mesmo lr, o modelo percorre muito mais a paisagem de loss por token. À medida que a curvatura local cresce (típico em modelos que começam a memorizar o subset pequeno), o passo de Adam fica grande demais para a Hessiana local → oscilação e eventual blow-up. Assinatura: `‖grad‖` sobe, loss de treino estagna e depois sobe.

2. **Ruído de gradiente × lr.** Batch de 32k tokens (256) vs 131k (1024). A escala de ruído é ~`1/√batch_tokens`. No mesmo lr, 256 tem ~2× mais ruído de gradiente relativo. Perto do fim do treino, quando o sinal é pequeno, o ruído domina e pode empurrar para fora da bacia.

3. **Weight decay acumulado.** 4× mais passos = 4× mais decaimento aplicado por token. Isso pode parecer regularização benéfica, mas combinado com lr efetivo alto gera dinâmica não-trivial (encolhimento + atualizações grandes), que é uma fonte conhecida de instabilidade em AdamW.

4. **Crescimento da norma dos logits / colapso de entropia de atenção.** Com 4× mais updates, a camada `output` e as cabeças tendem a crescer/afiar mais cedo. Se não houver gradient clipping nem monitoramento, logits explodem e a softmax satura → gradientes patológicos. Assinatura: `max|logit|` e `‖W_out‖` crescendo, entropia média de atenção caindo monotonicamente.

5. **Sobreajuste ao boundary (cold start).** 4× mais janelas por época = 4× mais tokens de início de janela (sem contexto). O modelo de 256 é treinado, por token, com muito mais frequência em regime “frio”. Isso desloca a distribuição de treino e, com mais passos, ele pode se especializar nesse regime — o que interage mal com a validação (ver §3.1) e pode gerar deriva representacional tardia.

**Importante distinguir divergência de overfitting:** divergência = loss de *treino* também sobe; overfitting = treino cai, val sobe. Com 20% de dados e 30 épocas, os dois são plausíveis e o protocolo atual não os separa. Você **precisa** de curvas por passo de train e val, não por época.

---

## 3. Outros confounds do protocolo (além do passo)

### 3.1 Validação enviesada pela janela
“Validado em 100% do val” não especifica *como*. Se a val também usa `stride = B/2`, então o val de 256 tem **4× mais tokens de boundary** que o de 1024, e boundary tem CE sistematicamente maior (falta de contexto). Isso **penaliza artificialmente o 256 na CE de validação** por um efeito puramente de janelamento, não de capacidade. Correção mínima: avaliar val em passe único por peça (sem stride) ou mascarar a loss dos primeiros `k` tokens de cada janela.

### 3.2 Padding e utilização de dados em peças curtas
`W(B) ≈ 2L/B` só vale para `L >> B`. LMD-clean tem peças curtas. Para peças com `L < 1024`, o ctx_1024 gera 1 janela (com padding) enquanto o 256 gera várias janelas plenas. Consequências:
- ctx_1024 **desperdiça dados** (padding) e tem menos exemplos efetivos → pode parecer “subtreinado” não por contexto, mas por utilização.
- A distribuição de comprimentos efetivos vista pelos dois modelos difere → confound de distribuição.
**Ação:** estratificar métricas por faixa de comprimento de peça e reportar a fração de tokens de padding por configuração.

### 3.3 Orçamento de passos vs tokens na comparação final
Com 30 épocas, ctx_1024 faz ~4,5k passos de AdamW. Para um Transformer de 6 camadas com warmup+cosine, isso pode ser **pouco** para convergir; ctx_256 com ~18k passos está confortavelmente treinado (ou overfitado). Comparar CE no “epoch 30” compara **pontos diferentes da trajetória de otimização**, não apenas contextos. Se a curva do 1024 ainda está descendo no epoch 30, o gap de CE está subestimando a vantagem de contexto.

### 3.4 Scheduler e warmup não especificados
- Se o cosine é definido em **passos totais de cada run**, a trajetória de LR em épocas é idêntica — ok.
- Se é definido em **um número fixo** (ex.: derivado do run de 1024) ou se o warmup é em passos fixos, o 256 completa o schedule 4× mais cedo em épocas e tem warmup 4× mais curto em tokens. Isso muda o regime de treino e pode, por si só, gerar instabilidade tardia no 256 (LR ainda alta quando o modelo já está em região de alta curvatura).
**Ação:** documentar scheduler, warmup e em que unidade (passos vs tokens) estão definidos.

### 3.5 Vazamento compositor/álbum no LMD-clean
Split de 20% por peça (seed 42) + val 100%: como LMD-clean tem múltiplas peças por compositor/álbum, uma fração grande dos compositores do val aparece no train. O modelo com **mais passos** (256) memoriza mais esses compositores → val inflado de forma desigual entre configurações. Isso pode mascarar o gap de generalização e interagir com a “divergência tardia” (memorização tardia de compositores vistos).
**Ação:** split por compositor (group split) ou, no mínimo, reportar métricas estratificadas por “compositor visto/não visto”.

### 3.6 Ordem de dados e dropout
Mesma seed, mas contagens de janelas diferentes → ordem efetiva de shuffling diferente e agregado de máscaras de dropout diferente. “Mesma seed” não controla a trajetória. Não é fatal, mas invalida afirmações de reprodutibilidade estrita entre runs.

### 3.7 Seleção de checkpoint e granularidade de avaliação
30 avaliações por run, mas 256 faz 4× mais treino entre avaliações → divergência pode ocorrer e ser mascarada entre épocas. Se você usa “best val checkpoint”, 256 tem 4× mais passos entre candidatos, o que muda a granularidade de seleção.

### 3.8 Sem réplicas
Uma seed por configuração → sem estimativa de variância. Dado que o efeito esperado (ΔCE ~0,1–0,4 nat) pode ser da ordem da variância entre seeds em subset pequeno, isso é sério. No mínimo, 2–3 seeds para 256 e 1024.

---

## 4. Diagnósticos mínimos para resgatar o experimento (sem refazer tudo)

1. **Logar por passo** (não por época): train loss, val loss (a cada N passos), `‖grad‖` pré-clip, `max|logit|`, `‖W_out‖`, entropia média de atenção por camada. Plotar **vs passo e vs token**.
2. **Classificar o que aconteceu no 256:** train sobe junto com val → divergência (edge of stability / grad noise). Train cai e val sobe → overfitting ao subset/compositores. Grad norm spike antecede a subida → confirma mecanismo 1/4.
3. **CE estratificada** por tipo de token e por posição na janela (buckets 0–10, 10–30, 30+) **com loss de boundary mascarada** — remove o viés do §3.1.
4. **Checar se 1024 ainda melhora no epoch 30.** Se sim, o experimento mede underfitting do 1024, não efeito de contexto.
5. **Estratificar por comprimento de peça** para quantificar o confound de padding (§3.2).
6. **Split por compositor** para quantificar vazamento (§3.5).

---

## 5. Re-runs mínimos para desconfundir (se houver GPU)

- **Controle de passos:** rodar ctx_256 por `30/4 ≈ 8` épocas (≈ mesmo nº de passos do 1024) e comparar em **tokens iguais**. Se o gap de CE persistir, o efeito é de contexto; se sumir, era orçamento de otimização.
- **Controle de lr:** repetir ctx_256 com `lr ≈ 3e-4/2` (escala √batch) ou `3e-4/4` (escala linear). Se a divergência tardia desaparecer, ela era lr efetivo, não contexto.
- **Gradient clipping** (`1.0`) em ambos: se estabiliza o 256, confirma mecanismo de edge of stability.
- **Validação sem stride** (passe único por peça): remove o viés de boundary.

---

## Veredito

O protocolo é **defensável como piloto**, mas não isola `block_size`. O stride proporcional garante orçamento **em tokens** igual, mas entrega **4× mais passos de AdamW** ao ctx_256, o que (i) confunde convergência com lr efetivo, (ii) confunde overfitting/divergência com contexto, e (iii) é um mecanismo plausível e suficiente para a instabilidade tardia observada no 256 — via edge of stability, ruído de gradiente, weight decay acumulado e crescimento de logits, todos amplificados por 4× mais updates. Some-se a isso o viés de validação por boundary e o vazamento compositor no LMD-clean, e a comparação de CE entre 256 e 1024 no epoch 30 fica **não-identificada**. Os diagnósticos do §4 e os re-runs do §5 são o mínimo para transformar esse ablation em evidência sobre modelagem de longo alcance.


---
