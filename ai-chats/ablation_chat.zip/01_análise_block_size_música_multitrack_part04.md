# 1. Análise block_size música multitrack

**Conversation ID:** `8d2f5c72-a3c8-4484-a142-c19f013f2a71`  
**Messages:** 8 (user: 4, assistant: 4)  
**Part:** 4/4 (messages 7–8)  

---

## Message 7 — *?*

### 👤 User

Nos resultados do ablation, ctx_1024 reduziu a validation cross-entropy em 25,92% (1.5298 → 1.1333) e a perplexidade em 32,73% (4.62 → 3.11), superando o melhor resultado de ctx_256 (época 26) já na época 3, enquanto ctx_256 divergiu nas épocas 28–30.

Porém, ao sintetizar 100 peças de cada variante com o mesmo Constrained Decoder e o mesmo SoundFont General MIDI, as métricas espectrais de áudio (FAD e KLD em janelas Hann de 1024 amostras a 16 kHz) ficaram estatisticamente indistinguíveis dentro de 1 desvio padrão.

Como explicar tecnicamente esse descompasso? Por que métricas espectrais de janela curta falham em capturar ganhos de coerência estrutural de longo prazo em música simbólica?


---

## Message 8 — *?*

<details><summary>💭 <em>thinking</em></summary>

```
The user is asking about a technical phenomenon: large CE/PPL gap between ctx_256 and ctx_1024 but FAD/KLD on short audio windows (1024 samples at 16 kHz = 64 ms Hann windows) are statistically indistinguishable. They want a technical explanation of why short-window spectral metrics fail to capture long-range structural coherence gains in symbolic music.

Let me think carefully about this.

Key facts:
- FAD and KLD computed on 1024-sample Hann windows at 16 kHz → 64 ms per window
- Audio rendered from MIDI via SoundFont GM
- CE dropped 25.92%, PPL dropped 32.73% (huge improvement)
- But FAD/KLD indistinguishable within 1 SD

Why would this happen? Let me enumerate mechanisms:

1. **Temporal resolution mismatch / timescale separation.** 64 ms windows capture at most ~2-3 note events at typical tempi (120 bpm = 8th note = 250 ms). Harmonic context needs 500ms-2s windows, phrase structure needs 4-16s. FAD/KLD on 64ms windows measure local timbre/spectral texture. The structural gains of ctx_1024 (phrase repetition, motivic coherence, cross-track coordination, cadences) live at 1-30 s scales. So the metrics are measuring the wrong timescale.

2. **Locality of spectral statistics.** FAD computes Fréchet distance between distributions of audio features (typically VGG-ish or mel-spectrogram features on short windows). KLD between spectral distributions. Both are marginal distribution distances — they compare histograms/means/covariances of local features. Two sequences with identical local statistics but different long-range order have identical marginal distributions. This is the classic "same n-gram distribution, different sequence structure" problem. Local spectral stats are essentially n-gram statistics of audio; they cannot distinguish "AABB" from "ABAB" or "AAAA" from "ABCD" if the local patches are the same. So if the model's note-level vocabulary/statistics are learned well by both (which they are, since even 256 covers a phrase), the local spectral content is similar.

3. **SoundFont rendering masks structure.** GM SoundFont synthesis is deterministic given note/velocity/timing. It doesn't add expressivity based on context. So audio is just a deterministic function of the symbolic sequence. Structural differences in symbolic sequence only manifest as timing/pitch differences, which at 64ms windows are hard to detect unless they change local spectra. Sustain/pedal/dynamics aren't modeled, so articulation doesn't carry structural information.

4. **Sampling variance / statistical power.** 100 pieces is small. FAD has high variance. With only 100 samples, the confidence intervals on FAD are wide. 1 SD may overlap. Also, FAD is known to be noisy and sensitive to implementation. If SD is large enough, "within 1 SD" is uninformative. This is an underpowered test.

5. **Both variants already "good enough" at local level.** Even ctx_256 with 256 tokens covers ~1.5 measures. Local note statistics (which pitch classes follow which, typical durations, density) are learned. So local spectral distributions converge. The gain of 1024 is in global coherence, which is not measured by local marginals.

6. **CE/PPL gap is partly optimizer artifact.** Given prior discussion, part of the CE gap is confounded (4× more Adam steps). So the "true" structural gain might be smaller than 25.92% suggests. Part of the CE gap could be from overfitting/boundary effects in val. So the actual difference in generated quality might indeed be smaller than CE suggests. This is important: the discrepancy might be partly real (CE overstates) and partly metric failure.

7. **Constrained Decoder narrows the gap.** The Constrained Decoder enforces syntactic validity (valid tokens, consistent durations, no overlapping notes, etc.). Both models' outputs go through it. This masks local errors. What remains is structural arrangement, which again is long-range.

8. **FAD's feature extractor.** If FAD uses a pretrained audio model (e.g., VGGish, CLAP, OpenL3) or mel-spectrogram stats, these were trained on human music for timbre/genre tasks, not structural coherence. They're sensitive to instrument mix, timbre, loudness, not phrase structure. Even if trained on music, the receptive field of VGGish is ~1 s (96 frames × 10ms hop? Actually VGGish uses 0.96s windows). So FAD windows are effectively ~1 s, still short.

Wait — the user says "FAD e KLD em janelas Hann de 1024 amostras a 16 kHz" — this suggests they're computing FAD on 64ms spectrogram frames? Or is the Hann window just for STFT and FAD operates on longer segments? Need to interpret. If FAD is computed on 64ms frames, it's very short. If they mean STFT frames of 64ms feeding into a spectrogram, and FAD over the whole piece, then FAD's temporal resolution is the FAD feature extractor's. But user says "métricas espectrais de áudio (FAD e KLD em janelas Hann de 1024 amostras)" — likely they mean they compute spectral distributions per 64ms window and then FAD/KLD on those distributions. Either way, short.

Actually FAD (Fréchet Audio Distance) typically uses VGGish embeddings which are 0.96s. But if they're doing FAD on 1024-sample windows directly, that's unusual. Let me treat it as: spectral features are computed on 64ms windows, and FAD/KLD compare distributions of these short-window features. That's even more local.

9. **Temporal statistics vs distributional statistics.** FAD/KLD measure distributions (mean, covariance), not temporal order. A model that produces looped 1-bar patterns vs. one that produces coherent 4-bar phrases will have same local spectral histogram if the local texture is similar. But perceptually very different. This is the core: **marginal distributions are invariant to temporal permutation.**

10. **Decoder temperature/sampling.** If sampling with temperature, both models' outputs might be locally similar; 256 might loop but the loop still has correct local statistics. 1024 might vary more but also correct local stats. FAD/KLD won't see the difference.

11. **Audio rendering normalization.** SoundFont rendering might normalize loudness or the mix, flattening differences. Velocity distributions might be similar.

12. **The 25.92% CE gap might be dominated by boundary TIME_SHIFT tokens** as I hypothesized earlier. If the gap is in boundary tokens (cold start), then generated music might not show the gap because generation with priming doesn't hit boundaries the same way, or because the model recovers quickly. But user said it's val CE on full pieces.

13. **Power analysis.** 100 pieces, FAD SD maybe ~0.5-2 depending on features. To detect a real effect, need N ≥ ... If the true effect size is small, 100 is underpowered. So "indistinguishable within 1 SD" might be a Type II error.

14. **FAD is not monotonic with perceptual quality for structured music.** Known criticism: FAD/KLD are distributional and don't capture musical structure, rhythm coherence, etc. Literature: FAD correlates with timbre/quality, not composition.

15. **Constrained decoder + SoundFont = deterministic local texture.** Given the same token vocabulary and same SoundFont, any valid token sequence produces similar local spectral content. The differences are in which notes are chosen and when, i.e., structure.

16. **Possible: ctx_256's divergence at epochs 28-30 means its checkpoint used might be epoch 26 (best). And 1024 at epoch 3 already better. But if both were trained similarly long, both produce locally plausible music.**

Let me also address: what would capture structural coherence? Metrics like:
- Self-similarity matrices / recurrence plots on symbolic or chroma features at longer timescales
- Compression-based metrics (e.g., normalized compression distance of symbolic sequences)
- Repetition/structure metrics (e.g., pattern discovery, LZ complexity)
- Long-range chroma/harmonic progression coherence
- Cross-track synchronization metrics
- Perplexity of a held-out symbolic LM on generated sequences (e.g., a pretrained model's likelihood)
- Human listening tests
- Groove/rhythm metrics (e.g., syncopation, rhythmic entropy at bar scale)

Also mention: FAD with longer receptive fields (e.g., using CLAP or MERT which have longer context), or metrics on symbolic representation directly (e.g., FAD on piano-roll, or "symbolic FAD" using MIDI embeddings).

Let me structure the answer:

1. **Framing: what each metric actually measures** — CE is token-level predictive, FAD/KLD are marginal spectral distributions over 64ms. These measure different things. The gap is expected, not paradoxical. But there are also real methodological issues.

2. **Timescale mismatch** — quantify: 64ms window at 120bpm 4/4 = 1/16 note. Structure lives at 1-30s. The window is 3 orders of magnitude too short. FAD's feature extractor (if VGGish) has ~1s receptive field; still short for phrase.

3. **Marginal distribution invariance** — the killer argument: FAD/KLD compare distributions, which are invariant to temporal permutation. Two sequences with same local n-gram stats have same FAD. Give concrete example: ABAB vs AABB with same note density/timbre → same spectral histogram, different structure.

4. **Constrained decoder + SoundFont flatten** — deterministic local rendering, masks local errors. Both models pass syntax; differences are structural.

5. **Statistical power** — 100 pieces, 1 SD overlap → Type II error. FAD variance is high. Underpowered.

6. **Part of the CE gap is confounded** — reference prior discussion: 25.92% may overstate true structural gain (4× Adam steps, boundary effects). So the "true" gap to detect might be smaller than CE suggests, making the null result more plausible.

7. **What the CE gap actually measured** — token-level, includes TIME_SHIFT boundaries, TRACK_SELECT. Not the same as perceptual structure.

8. **What would detect the difference** — longer-window FAD (CLAP, MERT), symbolic metrics (self-similarity, compression, pattern discovery, cross-track sync), chroma-based long-range, held-out LM perplexity on generations, human eval.

9. **Conclusion / recommended interpretation** — don't conclude "no difference"; conclude "this metric suite is blind to this difference." Report both, note the metrics measure different constructs, and recommend the right tools.

Also address: "Por que métricas espectrais de janela curta falham em capturar ganhos de coerência estrutural de longo prazo em música simbólica?" — Direct answer: because they are local marginals invariant to order, they don't see repetition/coordination/tonal trajectory; and music structure is defined by relationships across seconds, not by local timbre.

Let me quantify some numbers:

- 1024 samples @ 16kHz = 64 ms.
- At 120 bpm, 1 beat = 500 ms, 1 bar (4/4) = 2000 ms. 64ms = 1/8 of a beat ≈ a 32nd note. Actually 1/16 note = 125 ms at 120bpm. 64ms < 1/16 note. So window is smaller than one note. It's essentially spectral texture, can't even contain two notes usually. This is even stronger than I thought. Actually a Hann window of 64ms at 16kHz... FAD features from this would be essentially frame-level MFCC-like.

Wait, if window is 64 ms and notes are 125-500ms, the window sits inside a single note's spectrum. So it captures timbre of individual notes, not even chords. It measures instrument timbre, attack, decay. Both models use same SoundFont, so same timbre — explains indistinguishability.

FAD with 64ms frames is unusually short. Standard FAD uses VGGish with ~1s. So this is a very short-window variant. The KLD on spectral frames is essentially comparing spectral histograms = instrument/timbre distribution.

This is the key: **the window is shorter than a single note**. So it measures the SoundFont's timbre, not music. Since both use same SoundFont, distributions of timbre are identical unless note choice differs in a way that changes timbre (it won't — GM instruments are fixed per track).

Actually note: velocity affects timbre. So velocity distributions matter. But both models likely learn similar velocity distributions.

Also: pitch affects spectrum. But pitch class distribution might differ if tonal coherence differs. However, pitch class histogram is roughly stationary within a key; both models probably stay in key locally.

So indeed, 64ms windows measure timbre+velocity+local pitch, which are saturated at 256 context.

FAD being computed on 64ms frames — if FAD uses a pretrained embedding, the embedding's receptive field is what matters, not the 64ms. But user says FAD on 1024-sample windows, implying custom FAD on these frames. So it's a "spectral-frame FAD" which is very local.

I should note this: FAD was designed for ~1s+ segments. Using 64ms frames reduces it to a timbre distribution metric.

Let me also mention: if they used standard FAD (VGGish, 0.96s), the receptive field is ~1s, still shorter than phrase (2-8s). So even standard FAD would be blind-ish, but less so.

Let me also mention the "same n-gram distribution" formal argument: two Markov chains with same transition matrix but different global structure. FAD compares P(x) marginal of local features; structure is in P(x_1...x_T) joint. Local features are functions of short windows, so their distribution depends only on short-range marginals. Any long-range rearrangement preserving local marginals gives same FAD.

Concrete example: Take a valid piece, shuffle its 2-second segments (while keeping local validity). FAD same, structure destroyed. This is the invariance.

Also: FAD/KLD are known to be dominated by recording/production artifacts in audio (loudness, noise floor, mixing). Here, same SoundFont removes those, which is good for control but also removes the main axis FAD varies on. So FAD has no signal to latch onto.

Let me also mention mode collapse / local statistics: if ctx_256 loops, loops have same local stats as the coherent version. FAD won't see loop.

Let me draft the structure.

Also address "estatisticamente indistinguíveis dentro de 1 desvio padrão": need to mention that 1 SD overlap with N=100 might be underpowered; also FAD's bootstrap variance is large; KLD similar. Suggest power analysis: to detect a small effect (d=0.3) need N≈90 per group for 80% power, so 100 is borderline; but if true effect is d<0.3, need more.

Also, the 32.73% PPL reduction: from 4.62 to 3.11. That's substantial in token prediction. But token-level PPL on symbolic music overweights frequent tokens (TIME_SHIFT, NOTE). So reduction in PPL might be mostly in TIME_SHIFT/timing predictability, not in harmonic/pitch structure. This is worth noting: the CE gap might be mostly timing/boundary, which after rendering with quantized SoundFont might not translate to spectral differences because timing is quantized and both produce valid rhythms.

Actually, if ctx_1024 predicts TIME_SHIFT much better, then generated rhythms are more "correct" rhythmically. But local spectral windows don't measure rhythm well because 64ms < beat. However rhythm does affect spectrum over longer windows (rhythmic pattern creates spectral modulation). At 64ms, no.

Let me also discuss: FAD/KLD on audio are not aligned with symbolic structure by design. They were developed for audio generation tasks (e.g., music generation from audio, sound effects). For symbolic music, the right metrics are symbolic.

Recommended alternatives:
- Symbolic FAD (FAD on piano-roll or on MIDI embeddings)
- Self-similarity / recurrence metrics on chroma at bar scale
- Compression-based (NCD) comparing generations to held-out human pieces
- Cross-track synchronization / voice-leading metrics
- Long-range tonal coherence (key consistency over time, harmonic progression entropy)
- Groove metrics (syncopation, rhythmic density autocorrelation)
- "Predictability by a stronger model" — perplexity of a held-out large LM on generated sequences
- Human listening test (the gold standard)

Also mention: with the constrained decoder, the syntactic validity is enforced, so the remaining differences are exactly what FAD can't see.

Also mention: both models at 100 pieces generate, but if 256 diverged at 28-30, they likely used epoch 26 checkpoint (best val), so not diverged. Good.

Also mention potential: maybe there IS no perceptual difference at local level, but there would be at global level. The user's framing "fail to capture" is correct.

Let me also mention an important nuance: the CE gap might partly be genuine, partly confounded. 25.92% CE reduction is large for context doubling; typical is 10-20% PPL reduction from 256→1024 in LMs. So maybe some is confound. But even genuine, it's token-level.

Let me quantify: 25.92% CE reduction = 0.3965 nats. PPL ratio 4.62/3.11 = 1.485, ln = 0.395 nats. Consistent. That's a large gap. In language modeling, going from 256 to 1024 context gives maybe 0.1-0.2 nats. So 0.4 is suspiciously large — consistent with confound (4× Adam steps) plus boundary bias. So the "true" structural gain might be 0.1-0.2 nats, which would be even harder for FAD to detect.

Good point to make: the 25.92% likely overstates the structural gain due to the protocol confounds discussed earlier.

Let me write the answer in Portuguese, matching the conversation. Rigorous, structured, with headers.

Length: should be substantial but not enormous. Given the depth of prior responses, a thorough answer is expected. I'll aim for a well-structured analysis with quantitative reasoning.

Let me organize:

1. O descompasso é esperado — métricas medem construtos diferentes (brief framing)
2. Por que janela de 64 ms é cega (quantitative: 64ms < 1 nota; 3 ordens de grandeza abaixo de estrutura)
3. Invariância a permutação temporal (marginal vs joint; exemplo ABAB/AABB; formal argument)
4. SoundFont + Constrained Decoder achatam a variância que FAD mede (timbre controlado, sintaxe garantida)
5. Poder estatístico e ruído do FAD (N=100, 1 SD, Type II)
6. O gap de CE é parcialmente confound e parcialmente token-level (TIME_SHIFT, boundary) — portanto o "sinal" a detectar é menor do que parece
7. O que FAD/KLD realmente capturam aqui (distribuição de timbre GM)
8. O que mediria a diferença (alternativas)
9. Interpretação correta do resultado

Let me write.

One more: Hann window of 1024 samples at 16kHz = 64ms. FAD on this? FAD typically uses embeddings. If they compute spectral features per frame and then FAD on the set of frames, it's a distribution over frames. If FAD uses pretrained model, the model's receptive field dominates. But user says "FAD e KLD em janelas Hann de 1024 amostras a 16 kHz" — I'll interpret as: features computed on 64ms windows; FAD/KLD compare distributions of these features. Even if a pretrained extractor, its receptive field may be larger; but let me note this nuance.

Actually, I should clarify: standard FAD (Kilgour et al. 2019) uses VGGish, which takes 0.96s inputs and has ~1s receptive field. If they're computing FAD with 64ms windows, they're either using VGGish on 64ms (unusual, VGGish expects 0.96s) or computing custom spectral features. Either way, the effective temporal resolution of the comparison is at most the extractor's receptive field. If VGGish, ~1s — still < phrase. If raw spectral frames, 64ms.

I'll mention both interpretations but focus on the principle: effective timescale of comparison ≤ extractor receptive field, which is ≤1s and likely much less.

Also KLD on spectral distributions: if KLD is between average spectra of the two sets, it's essentially comparing mean timbre. If KLD between frame-level distributions, similar.

Let me also mention: FAD is a Fréchet distance between Gaussians fitted to feature distributions. It captures mean and covariance of features. Covariance across frames could capture some temporal statistics if features are time-ordered, but typically FAD treats frames as iid. So no temporal order.

Now, another important angle: the 25.92% CE improvement might manifest as "more likely continuations" but both models produce locally valid music. The FAD test is on generated samples, not on likelihood. If generation uses temperature and constrained decoding, the samples from 256 might still be locally fine (because local stats are learned) but globally loop. FAD misses loops.

Also: with only 100 pieces, if the 1024 model generates more varied music (less looping), the marginal distribution might actually be MORE different... but FAD compares to reference; both are compared to same reference (human music). Both might be similarly close in local timbre distribution because both use same SoundFont and valid notes. The difference in structure doesn't change distance to reference in local spectral space.

Actually, a subtle point: if reference human music has long-range structure, and 256 generates loops while 1024 generates varied phrases, then FAD-to-reference might differ if FAD captured structure. Since FAD is local, both are equally close. So FAD-to-reference is blind to structural fidelity. This is the "reference also has structure but FAD ignores it" point.

Good.

Also mention: perceptual studies show listeners detect structure at 2-10s scales; audio metrics need that receptive field.

Let me also mention "FAD is known to be insensitive to musical structure" with citations: Kilgour et al. 2019 introduced FAD; multiple papers note FAD doesn't capture structure; e.g., "FAD correlates with timbre, not composition" — there's literature on this (e.g., work by Bhandari et al., or the "On Evaluation Metrics for Music Generation" papers). I'll mention generally without over-citing.

Let me write final answer in PT-BR.

I'll be careful to:
- Be rigorous, act as reviewer
- Quantify
- Give falsifiable explanations
- Suggest next steps

Length: maybe 900-1200 words in PT. Given prior answers were long, I'll match but not exceed. Let me aim for comprehensive but tight.
```

</details>

### 🤖 Assistant

# Por que o gap de CE não aparece no FAD/KLD — e por que isso é esperado

## 1. Enquadramento: as métricas medem construtos diferentes

O descompasso não é paradoxal; é o comportamento previsto quando se compara uma métrica **de likelihood token-a-token em escala de peça** (CE) com métricas **de distribuição marginal de espectro em janelas de 64 ms** (FAD/KLD). Elas respondem perguntas diferentes:

- CE: "quão provável é o próximo token dado todo o prefixo até `block_size`?" — sensível a ordem, a dependências de longo alcance, a boundary.
- FAD/KLD em janelas de 1024 amostras: "as estatísticas locais de timbre/spectro dos dois conjuntos de áudio são parecidas?" — **invariantes a permutação temporal** e cegas a ordem.

O resultado "CE melhora 26%, FAD não muda" é consistente com: *o ganho de ctx_1024 está em estrutura de longo alcance, e a métrica de áudio não enxerga estrutura de longo alcance.* Abaixo, os mecanismos concretos — e também os confounds que tornam o resultado menos informativo do que parece.

---

## 2. A janela é curta demais — quantitativamente

1024 amostras a 16 kHz = **64 ms**. A 120 bpm em 4/4:

| escala musical | duração | múltiplo da janela |
|---|---|---|
| 1/16 note | 125 ms | ~2× |
| 1 beat | 500 ms | ~8× |
| 1 compasso | 2 s | ~31× |
| frase (2–4 compassos) | 4–8 s | ~60–125× |
| seção | 16–30 s | ~250–470× |

A janela é **menor que uma nota típica** (125–500 ms). Ela não contém um acorde, não contém um par de notas, não contém um tempo forte. Ela mede o **espectro de um único evento**: timbre do instrumento GM, ataque, decaimento, conteúdo harmônico local. Como ambas as variantes usam o **mesmo SoundFont GM**, o timbre por instrumento é idêntico por construção; só muda a *distribuição de quais notas/velocidades aparecem*. E essa distribuição local satura rapidamente — ctx_256 já a aprende.

Mesmo que o FAD use um extrator pré-treinado (VGGish, ~0,96 s de campo receptivo), o teto é ~1 s, ainda **abaixo da escala de frase**. O resultado é o mesmo: o comparador opera em escala de textura, não de estrutura.

---

## 3. Invariância a permutação: o argumento decisivo

FAD é uma distância de Fréchet entre gaussianas ajustadas à distribuição de features; KLD compara distribuições. **Distribuições marginais de features locais são invariantes à ordem temporal.** Formalmente: se a feature `f` depende de uma janela de `w` amostras, então `P(f)` depende apenas das marginais de curto alcance de `x`. Qualquer rearranjo de `x` que preserve essas marginais (ex.: embaralhar blocos de 2 s mantendo validade local) deixa `P(f)` — e portanto FAD e KLD — **exatamente iguais**, embora destrua toda a estrutura musical.

Exemplo concreto: `ABAB` (motivo repetido coerentemente) e `AABB` (blocos justapostos) têm o mesmo histograma de texturas locais. Uma versão que entra em loop de 1 compasso e uma que desenvolve frases de 4 compassos têm o mesmo FAD se a textura local for a mesma — e é, porque ambas usam as mesmas notas válidas, o mesmo SoundFont e a mesma densidade local. **FAD mede `P(x_t)` marginal; estrutura vive em `P(x_1…x_T)` conjunta.**

Isso é agravado pelo **Constrained Decoder**: ele garante validade sintática (tokens válidos, durações coerentes, sem sobreposição). O que sobra de diferença entre 256 e 1024 é exatamente a *organização* — o que o FAD descarta por construção.

---

## 4. O SoundFont achata justamente o eixo em que o FAD varia

Em áudio natural, FAD/KLD são dominados por **produção**: loudness, ruído de fundo, mixagem, reverb, variação de timbre. Aqui, a renderização GM é determinística e idêntica entre variantes — o eixo principal de variância do FAD foi **controlado para fora**. Sobra pouca variância para o FAD discriminar, e a que sobra (pitch/velocidade) satura em contexto curto. O controle experimental que você fez (mesmo SoundFont, mesmo decoder) é correto para isolar o modelo — mas tem como efeito colateral **remover o sinal que o FAD foi desenhado para captar**.

---

## 5. Poder estatístico: "dentro de 1 SD" com N=100 é inconclusivo

FAD tem variância alta e bootstrap ruidoso; KLD sobre distribuições espectrais idem. Com N=100 por variante:

- Para detectar um efeito pequeno (d≈0,3) com 80% de poder, precisa-se de ~90–180 por grupo — 100 está no limite.
- "Dentro de 1 SD" não é evidência de equivalência; é **falha de rejeição**. Ausência de evidência ≠ evidência de ausência. Sem um teste de equivalência (TOST) com margem pré-registrada, o resultado é **Type II error plausível**, não "não há diferença".

Some-se a isso que o FAD, por ser distância entre gaussianas de features, tem intervalos de confiança largos e sensíveis a implementação — reportar "1 SD" sem IC bootstrap por peça é frágil.

---

## 6. Parte do gap de CE é confound — o "sinal" a detectar é menor do que 26%

Pela análise anterior: ctx_256 recebeu **4× mais passos de AdamW** no mesmo orçamento de tokens, com batch em tokens 4× menor e weight decay acumulado 4× maior. Um gap de 0,396 nats por duplicação de contexto é **grande demais** para ser só contexto (na literatura, 256→1024 em LMs rende ~0,1–0,2 nats). Boa parte dos 25,92% é provavelmente:

- lr efetivo / ruído de gradiente (favorecendo o 1024 por ser mais estável),
- **viés de boundary na validação**: ctx_256 tem 4× mais tokens de início de janela (cold start), que concentram CE alta — e o `TIME_SHIFT` no início de janela é o token mais afetado.

Ou seja: o gap *estrutural genuíno* pode ser bem menor que 26%, e possivelmente concentrado em **timing/boundary** (`TIME_SHIFT`), não em escolha de pitch/harmonia. Se for esse o caso, o efeito no áudio renderizado é ainda mais tênue: timing quantizado + SoundFont determinístico + decoder restrito → a diferença de CE em `TIME_SHIFT` pode não se traduzir em diferença espectral detectável. **Os dois resultados podem estar corretos simultaneamente**: CE menor por melhor modelagem de timing/boundary, FAD igual porque timing local já era plausível em ambos.

---

## 7. O que mediria a diferença (e o que o FAD não mede)

Para capturar o que ctx_1024 ganha, é preciso sair de marginais locais:

**Em símbolo (recomendado, alinhado ao construto):**
- Auto-similaridade / recurrence plots em chroma ou piano-roll na escala de 1–16 s; detecção de repetição motívica.
- Métricas de compressão (NCD) das sequências geradas contra peças humanas de held-out — sensível a estrutura que n-gramas locais não capturam.
- Coerência tonal de longo prazo: entropia de progressão harmônica por compasso, consistência de centro tonal ao longo de 30 s.
- Sincronização cross-track: coincidência de onsets, defasagem de imitação entre trilhas em escala de compasso.
- Perplexidade de um LM simbólico held-out (maior, com contexto longo) sobre as gerações — proxy de "quão musicalmente previsível" é a sequência.
- Groove: autocorrelação rítmica, syncopation em escala de compasso.

**Em áudio, se quiser manter:**
- FAD com extrator de **campo receptivo longo** (CLAP, MERT, ou features em janelas de 2–8 s), não 64 ms.
- Métricas de novidade/estrutura sobre embeddings de longo alcance (self-similarity matrices de embeddings musicais).
- Teste de escuta humana — o gold standard para coerência estrutural, e o único que captura o que "soa coerente ao longo de 30 s".

**Controle necessário:** avaliar geração em **peças longas** (≥30 s) com rolling window, porque é aí que a diferença de contexto se manifesta. Se a geração foi limitada a poucos segundos, ambos os modelos operam dentro do regime em que 256 já satura — e o teste é estruturalmente incapaz de separar.

---

## 8. Interpretação correta do resultado

O resultado conjunto deve ser lido como:

1. **Há evidência de que contexto maior melhora a likelihood token-level** — mas parte do efeito é confound de otimização e boundary, e o efeito estrutural genuíno é menor que 26%.
2. **Não há evidência, com este conjunto de métricas, de que essa melhora se traduza em diferença espectral local** — o que é esperado, porque as métricas medem timbre/textura local, invariantes a estrutura, e o SoundFont/decoder removeram os eixos em que o FAD varia.
3. **A conclusão válida não é "ctx_1024 não melhora a música"**, e sim **"a suíte FAD/KLD de 64 ms é cega ao construto que o contexto melhora"**. Para decidir entre as hipóteses "ganho só em timing/boundary" vs. "ganho em estrutura de longo alcance", é preciso a bateria simbólica do §7 em gerações longas — e, idealmente, escuta humana.

Em termos de revisão: o experimento de áudio, como está, **não falsifica nem confirma** a hipótese estrutural; ele é um teste de poder baixo com uma métrica de validade de construto inadequada para a pergunta. Reportá-lo como "indistinguível" sem essa ressalva seria um erro de interpretação.


---
