# 1. Análise block_size música multitrack

**Conversation ID:** `8d2f5c72-a3c8-4484-a142-c19f013f2a71`  
**Messages:** 8 (user: 4, assistant: 4)  
**Part:** 2/4 (messages 3–4)  

---

## Message 3 — *?*

### 👤 User

Quero projetar um ablation study controlado mantendo arquitetura, vocabulário (650 tokens), otimizador (AdamW, lr=3e-4) e orçamento de treino fixos, variando apenas o block_size entre 256 e 1024 tokens.

Considerando que um fluxo intercalado de até 10 instrumentos infla rapidamente o número de tokens por compasso:

    Que hipóteses quantitativas e qualitativas devo esperar em termos de validation cross-entropy, perplexidade e velocidade de convergência?

    O que acontece com a atenção causal quando um trecho musical de poucos segundos já consome quase toda uma janela de 256 tokens?


---

## Message 4 — *?*

<details><summary>💭 <em>thinking</em></summary>

```
The user wants an ablation study design with block_size varying 256–1024, fixed everything else. They ask for quantitative and qualitative hypotheses on val CE, perplexity, convergence speed, and what happens to causal attention when a few seconds of music consume nearly the entire 256-token window.

Let me think carefully about this.

Setup: 650 tokens vocab, 10ms resolution, up to 10 tracks, interleaved global timeline with TRACK_SELECT. d_model=256, 6 layers, 8 heads, FFN=1024, dropout=0.1, AdamW lr=3e-4, fixed training budget (fixed number of gradient steps or fixed tokens seen? "orçamento de treino fixo" — ambiguous. Likely fixed number of optimizer steps or fixed wall-clock/tokens. I should discuss both interpretations because it changes convergence speed conclusions).

Token density per bar: at 120 bpm 4/4, one bar = 2 s = 200 time units of 10ms. If notes are ~1/8 or 1/16, and 10 tracks, events per bar could be: each track maybe 4-8 notes/bar → 40-80 note tokens + onsets/durations/velocities? Depends on encoding. Vocab 650 suggests REMI-like: note-on/off per track, time shifts, track select, velocity bins. Let's estimate: per bar, per track, say 4 note events × (track select + time shift + note + velocity) ≈ 4×4 = 16 tokens, ×10 tracks = 160 tokens/bar. Plus time shifts accumulate. So 256 tokens ≈ 1.5 bars ≈ 3 seconds. That's the key: 256 tokens ≈ 1–2 bars, a few seconds.

So with block_size=256, the model sees about 1–2 bars. That's basically one chord progression or a single motif. With 1024, ~6–10 bars, a phrase/section.

Quantitative hypotheses on val CE / PPL:

- PPL = exp(CE). CE in nats. If CE drops by 0.1 nat, PPL drops by ~10%.
- Hypothesize CE_256 ≈ 2.6–2.9, CE_512 ≈ 2.4–2.6, CE_1024 ≈ 2.2–2.4. But careful: smaller context can actually *lower* training loss early because easier prediction task (local statistics dominate), but generalize worse on long-range metrics. Also with fixed budget in steps, smaller block = more sequences per token budget? If fixed number of tokens seen, same. If fixed steps, smaller block sees fewer tokens → worse. Need to address.

Important subtlety: CE is averaged per token. Shorter context → the model can't condition on long history, so if the true distribution has long-range dependencies, CE is higher (worse). But there's a confound: with shorter windows, the model trains on more "sequence starts" which are more predictable (beginning of piece has more uncertainty actually — the first tokens have no context, so they're higher loss). Actually with shorter windows, a larger fraction of tokens are near the beginning of the window with little context → higher average loss. This is a real effect: the "context dilution" at window boundaries. So even if long-range structure is irrelevant, shorter windows have higher CE because more tokens are in low-context positions. This is a known effect.

Quantitatively: if we assume a power-law-ish improvement with context length, CE improvement roughly logarithmic in context. Typical numbers in language modeling: doubling context gives maybe 0.05–0.15 nat improvement in this regime. For music with strong local structure, the gain may saturate faster but multitrack long-range coherence benefits.

PPL: exp(CE). CE 2.8 → PPL 16.4; CE 2.5 → PPL 12.2; CE 2.2 → PPL 9.0.

Convergence speed: with fixed optimizer steps and lr, smaller block_size = cheaper per step → more steps in same wall-clock, but "orçamento de treino fixo" probably means fixed compute or fixed steps. If fixed steps: 256 converges to lower train loss faster (easier task, more updates per token? no—same steps, fewer tokens per step). Actually smaller block: each step processes 256 tokens vs 1024, so with fixed steps the 256 model sees 4× fewer tokens total → undertrained. If fixed tokens: same tokens, 4× more steps for 256 → faster convergence per token budget? More gradient updates usually helps early convergence. So the interpretation matters a lot. I should explicitly flag this confound and recommend fixing tokens-seen AND steps (i.e., fixed tokens, report steps).

Better: recommend fixing "tokens seen" as the budget, which means 256 runs 4× more steps. Then 256 will converge faster in wall-clock to a given CE but plateau higher. Or fix steps → 256 sees fewer tokens, undertrained, lower absolute performance but it's a confound.

Qualitative hypotheses:

- 256: learns local note statistics, chord tones, rhythmic motifs within a bar; fails at phrase-level repetition, call-response between tracks, cadences, cross-track imitation; generation drifts, loses track coherence, more prone to "stuck" loops and local repetition; constrained decoder does heavy lifting.
- 512: intermediate; captures 2–4 bar motifs, simple harmonic progressions; some cross-track coordination.
- 1024: captures phrase structure, section repetition, cross-track motifs; better long-range coherence; but attention budget spread, may still fail beyond ~8 bars.

Attention behavior at 256 with few seconds filling window:

- The causal attention at any position near the end of the window attends over ~256 tokens, but those tokens span only ~1.5 bars, so the receptive field in *musical time* is tiny. Each track gets ~25 tokens of its own history (256/10). That's ~6 notes of history per track. Cannot model motif repetition of length > 6 notes, cannot model harmonic progression over 4 bars.
- Attention entropy: with few, dense, locally-correlated tokens, attention distributions may become sharper/more local (attending to recent same-track tokens), and the model may overfit to local patterns. The "attention sink" phenomenon at sequence start becomes proportionally more important: with 256, the first ~10–20 tokens are a large fraction, and boundary effects (padding/start) contaminate more.
- Effective receptive field in musical time ≈ block_size / tokens_per_second. tokens_per_second ≈ 160 tokens/bar / 2 s = 80 tokens/s. So 256 tokens ≈ 3.2 s; 512 ≈ 6.4 s; 1024 ≈ 12.8 s. Good concrete numbers.
- With 10 tracks, per-track history at 256: ~25 tokens ≈ 0.3 s of that track's own events? Actually 25 tokens of that track ≈ 6 notes ≈ 1.5 bars if 4 notes/bar. So per-track receptive field ~1 bar. At 1024: ~100 tokens ≈ 25 notes ≈ 6 bars.

Also: positional embedding capacity. PE embedding is block_size × d_model. With 256, PE table small — fine. Extrapolation not an issue since training matches. But the model trained at 256 can't generate >256 without sliding windows; comparison fair if generation also uses sliding window or truncated.

Also: causal mask overhead and the "no future" issue is same. But a subtle point: with a small window, the model is forced to treat window boundaries as pseudo-document boundaries — it learns that context resets, which can harm generation where you want continuity. This creates a train/inference mismatch if inference uses rolling context longer than training.

Statistical power / confounds:
- Fixed budget: specify tokens-seen (e.g., 2^? tokens) so 256 does 4× steps. Otherwise confounded.
- Learning rate: 3e-4 fixed; smaller models/contexts may prefer same lr; but note that with 4× more steps at 256, you may want a longer cosine schedule — schedule length must be in steps, which differs → confound. Recommend cosine schedule defined in tokens or matched final LR.
- Batch size: fix in tokens (e.g., 8×1024 tokens) or sequences; recommend fixed tokens per batch to keep gradient noise comparable.
- Dropout fixed at 0.1: smaller context → higher overfitting risk on local patterns? Actually less capacity to overfit long-range; but with more steps, overfitting risk.
- Evaluate CE per token, but also stratify by position-in-window and by token type (TIME_SHIFT vs NOTE vs TRACK_SELECT) — shorter windows will show worse TIME_SHIFT/duration prediction because timing drift accumulates.

Metrics to add:
- CE stratified by token type and by distance-to-window-start.
- Musical metrics: bar-level self-similarity, motif repetition rate, cross-track synchronization (e.g., onset coincidence), pitch-class histogram distance to training, repetition ratio (like Inception score/self-similarity), long-range coherence over 30 s generations.
- Attention diagnostics: attention entropy, average attention distance (in musical time, not tokens), fraction of attention to same track (via TRACK_SELECT segmentation), head specialization.

Predictions table:

block_size | tokens/s (~80) | musical span | per-track history | val CE (nats) | PPL | qualitative
256 | 3.2 s | ~1.5 bars | ~6 notes | ~2.7–3.0 | ~15–20 | local only
512 | 6.4 s | ~3 bars | ~12 notes | ~2.5–2.7 | ~12–15 | motif-level
1024 | 12.8 s | ~6 bars | ~25 notes | ~2.3–2.5 | ~10–12 | phrase-level

I should be clear these are hypotheses/priors, not guaranteed, and give the expected *shape*: diminishing returns, likely largest gain 256→512, smaller 512→1024 if local structure dominates, or the opposite if long-range structure is strong. Argue music likely has strong local + moderate long-range, so expect log-linear in log(block_size): ΔCE ≈ a·log2(block). From 256→1024 = 2 doublings; if a≈0.1–0.15 nat/doubling, total ~0.2–0.3 nat, PPL reduction ~20–25%.

Convergence speed: at fixed steps, 256 trains faster per-step (lower loss sooner) but plateaus higher on long-range; at fixed tokens, 256 gets 4× steps, converges faster to its plateau. Predict: 256 reaches its plateau in ~1/3 of wall-clock but plateau CE ~0.2–0.4 nat higher than 1024. 1024 has slower early convergence (fewer steps per token, higher variance per step) but better asymptotic.

Also mention: with fixed lr 3e-4 and more steps at 256, risk of overfitting/noise; maybe early stopping differences.

Attention at 256 details:
- Every position sees at most 255 predecessors; the first token sees none. The "effective context" distribution is triangular: average context length = 128, but the fraction of tokens with full-window context is small. Actually average context length at 256 = ~128, at 1024 = ~512. So CE is dominated by mid-sequence tokens; boundary effects proportionally larger at small windows because the ramp-up (say first 20 tokens) is a bigger fraction (8% vs 2%).
- Attention distance in musical time: max ~1.5 bars. No head can specialize in long-range cross-track imitation. Heads will specialize in local onset/chord/rhythm.
- With TRACK_SELECT as the only track signal, attention across tracks at small windows is fine (recent tokens of other tracks are near), but "who played what two bars ago" is out of reach.
- Padding mask + causal mask: with batch sequences of varying length ≤256, many short sequences; padding fraction higher if data windows are shorter than block (but likely you chunk to full block). If you pad, compute waste.

Also mention the mismatch between training window and generation: autoregressive generation beyond 256 needs rolling KV cache; train/test distribution mismatch grows with generation length; constrained decoder masks become more important.

One more: positional embedding table size difference means parameter count differs slightly (256×256 vs 1024×256 = 65k vs 262k params). Negligible (~0.2% of ~? total). Total params: embedding 650×256=166k, PE 256/1024×256, 6 layers × (attn 4×256²=262k + FFN 2×256×1024=524k) ≈ 6×786k≈4.7M + output 166k. So PE is <5%. Note.

Also worth noting: fixed vocab 650 and d_model 256 → embedding/output dominate less.

I should also address: "orçamento de treino fixo" — I'll explicitly call out that the answer branches on whether budget is steps or tokens, and recommend tokens-seen + report both.

Also mention evaluation noise: with 4× different sequence counts, val CE variance; use same val token set, bootstrap CI.

Let me structure the answer:

1. Premissa de calibração: tokens/segundo e spans (concrete numbers).
2. Confound crítico do orçamento fixo (steps vs tokens) — must resolve first.
3. Hipóteses quantitativas: CE, PPL, shape (log-linear in log block), table with ranges, per-token-type stratification prediction.
4. Velocidade de convergência: predictions under both budget interpretations.
5. Qualitativas: what each window can/can't learn; generation pathologies.
6. O que acontece com atenção causal a 256: triangular context, receptive field in musical time, per-track history, attention entropy/localization, boundary contamination, head specialization, train/inference mismatch.
7. Recomendações de medição para o ablation ser controlado: stratify CE by position and token type, attention diagnostics, musical metrics, statistical protocol.

Keep in Portuguese. Use concrete numbers but flag as priors. Be honest about uncertainty.

Length: substantial but focused. Use headers and a table. No excessive lists of generic advice. The user is sophisticated — go deep on the attention mechanics at 256.

Let me compute tokens/second more carefully. 120 bpm, 4/4 → 2 s/bar. 10ms resolution → 200 ticks/bar. If encoding uses TIME_SHIFT as delta in ticks with vocab of time shifts (e.g., 1..100 then multiples), a note event = TRACK_SELECT? Actually TRACK_SELECT per event or per track-switch? In interleaved global order, you emit TRACK_SELECT whenever track changes. If notes are simultaneous, you group by track: for each timestamp, list events per track. So per timestamp: TIME_SHIFT + (TRACK_SELECT + NOTE + VELOCITY)×k tracks active. If average 3 tracks active per 16th note... Let's just say tokens/bar 120–250, central ~160. tokens/s ≈ 80. I'll present as 60–100 tokens/s range, central 80.

At 256: 3.2 s ≈ 1.6 bars. Per track (10): 25 tokens ≈ if 4 events/bar/track → 6 events ≈ 1.5 bars. Good.

At 1024: 12.8 s ≈ 6.4 bars; per track ~100 tokens ≈ 25 events ≈ 6 bars.

Now CE numbers. For symbolic music LM with vocab 650, typical val CE ~2–3 nats (PPL 7–20). I'll give priors with caveat.

I'll also note that CE gains from context are usually sublinear and follow ~ -a log(block) + b; estimate a from literature ~0.05–0.2 nat per doubling for music; so 256→1024 (2 doublings) ~0.1–0.4 nat.

Also the "boundary ramp" effect: average context length = block/2 but tokens with short context have higher loss; the excess loss from ramp scales as ~ (ramp_tokens/block) × Δloss. At 256 ramp of ~20 tokens = 8%, at 1024 = 2%. If ramp tokens have +1 nat excess over asymptotic, contribution difference ~0.06 nat. Not huge but non-negligible and biases toward larger block independent of long-range modeling.

Another subtle: TIME_SHIFT prediction. At 256, the model often starts mid-phrase; the first TIME_SHIFT after window start has no prior timing context → high loss. More window starts per token → higher TIME_SHIFT CE at small block. Predict stratification: CE gap concentrated in TIME_SHIFT and first ~20 positions, not in NOTE tokens mid-window. This is a testable, falsifiable prediction — good for the ablation.

Also: if windows are random crops, the distribution of "start mid-note vs start at note boundary" matters. Random crop can start mid-event; recommend cropping at bar/beat boundaries or at TIME_SHIFT boundaries to avoid impossible continuations (a NOTE token without its onset context). Actually starting mid-event is fine in interleaved encoding as long as tokens are self-contained, but starting right after a TRACK_SELECT without a note is weird. Mention crop strategy as a control.

Attention at 256 — mechanism:
- Causal mask triangular; each query attends ≤ its position. Average attended context = (L+1)/2 ≈ 128 vs 512.
- Softmax over few tokens → higher variance, sharper distributions; with 8 heads and small L, heads may collapse to similar local patterns; less need for global heads.
- "Attention distance" measured in musical time is capped at window span (3.2 s at 256). No head can implement "same as 2 bars ago" because that's outside window. So the model's inductive bias for repetition is limited to within-window recurrence.
- Attention sink / first-token: with LayerNorm pre-norm and causal, early tokens act as sinks; at 256 the relative cost of the sink region is larger.
- Cross-track: TRACK_SELECT tokens are frequent; attention can easily attend to recent same-track tokens because they're within 25 positions. But if a track is silent for 2 bars (200 ticks), at 256 that history is gone → model can't condition on it.
- Padding mask: batch of 256 with variable lengths → more padding if sequences shorter; but standard chunking to full length avoids this.

Also mention: 8 heads, d_head=32 at d_model=256. At small L, attention patterns may be dominated by positional proximity; measure attention distance distribution.

Train/inference mismatch: if you train at 256 but generate with rolling window of 1024 (or full piece), the model never saw positions >256, PE fails. If you generate with 256 rolling, quality limited by 3 s memory. This is a key qualitative outcome: 256 is not just "worse CE," it's structurally incapable of long-range coherence, and the constrained decoder will mask the symptom partially by forcing valid syntax but not musical structure.

I'll also propose pre-registered decision rule: if CE gap 256 vs 1024 < ~0.1 nat and musical metrics (motif repetition) don't differ, then long-range context isn't the bottleneck and representation/encoding is; if gap > 0.3 nat concentrated in TIME_SHIFT, the issue is boundary/timing and you should change encoding (coarser time, bar tokens) rather than just bigger window. Nice actionable.

Write it.
```

</details>

### 🤖 Assistant

# Ablation de `block_size` (256–1024): hipóteses e mecânica da atenção

## 0. Calibração de escala — sem isso as hipóteses são vagas

A 120 bpm em 4/4, 1 compasso = 2 s = 200 ticks de 10 ms. Com até 10 trilhas intercaladas, um evento típico custa `TIME_SHIFT + TRACK_SELECT + NOTE + VELOCITY` (≈4 tokens), e notas simultâneas de trilhas distintas são serializadas. Ordem de grandeza: **~120–250 tokens/compasso, central ~160** → **~60–100 tokens/s, central ~80**.

Daí:

| `block_size` | span musical | compassos | histórico por trilha (÷10) | notas de histórico/trilha |
|---|---|---|---|---|
| 256 | ~3,2 s | ~1,5 | ~25 tokens | ~6 |
| 512 | ~6,4 s | ~3 | ~50 tokens | ~12 |
| 1024 | ~12,8 s | ~6–7 | ~100 tokens | ~25 |

A conclusão estrutural: **mesmo 1024 mal cobre uma frase musical**; 256 cobre *um motivo*. Isso enquadra tudo abaixo.

---

## 1. O confound que precisa ser resolvido antes: "orçamento fixo" em quê?

"Orçamento de treino fixo" é ambíguo e **muda a conclusão sobre velocidade de convergência**:

- **Fixo em passos de otimizador:** o modelo de 256 vê 4× menos tokens que o de 1024. Ele vai parecer "convergir rápido" (loss de treino cai cedo) mas está subtreinado — comparação inválida.
- **Fixo em tokens vistos (recomendado):** o de 256 faz 4× mais passos. Convergência por token melhora (mais updates), mas o schedule cosine, se definido em passos, termina em pontos diferentes — outro confound.

**Protocolo mínimo para o ablation ser controlado:** fixar *tokens vistos* como orçamento, definir o schedule de LR em **tokens** (não em passos), manter batch em **tokens** (ex.: 8×1024 tokens por passo efetivo, via grad accumulation para o 256), e reportar CE vs. tokens vistos *e* vs. wall-clock. Sem isso, qualquer diferença de "velocidade de convergência" é artefato.

---

## 2. Hipóteses quantitativas: CE e perplexidade

### Forma esperada

Ganho de contexto em LMs simbólicos é tipicamente **sublinear e aproximadamente linear em log₂(block_size)**: ΔCE ≈ −a·log₂(B) + b, com a ≈ 0,05–0,20 nat por duplicação na faixa 256–1024. De 256 a 1024 são 2 duplicações → **ΔCE total esperado ≈ 0,1–0,4 nat**, com PPL caindo ~10–30%.

### Priors numéricos (a validar, não previsões pontuais)

| `block_size` | val CE (nats) | PPL = e^CE | ΔCE vs 256 |
|---|---|---|---|
| 256 | 2,7–3,0 | ~15–20 | — |
| 512 | 2,5–2,7 | ~12–15 | −0,2 a −0,3 |
| 1024 | 2,3–2,5 | ~10–12 | −0,3 a −0,5 |

**Assimetria esperada:** o maior salto é 256→512 (sai de "um motivo" para "dois–três motivos", onde repetição motívica e progressão harmônica simples passam a ser modeláveis); 512→1024 traz ganho menor, a menos que o LMD-clean tenha forte estrutura de seção. Se o ganho 512→1024 for *maior* que 256→512, é sinal de que a estrutura relevante é de frase/seção — resultado informativo por si.

### Onde o gap deve se concentrar (predição falsificável)

O gap de CE **não deve ser uniforme por tipo de token**. Predição:

1. **`TIME_SHIFT` concentra o gap.** Cada início de janela começa sem contexto temporal; o primeiro `TIME_SHIFT` após o boundary tem loss muito acima da média. Com 256 há 4× mais boundaries por token → CE de `TIME_SHIFT` sobe desproporcionalmente.
2. **Primeiros ~20–30 tokens da janela concentram o gap** (rampa de contexto). Em 256 isso é ~8–12% dos tokens; em 1024, ~2–3%. Só esse efeito de boundary contribui ~0,05–0,1 nat de diferença *independente de dependência de longo alcance*.
3. **`NOTE`/`VELOCITY` no meio da janela quase não diferenciam** entre 256 e 1024 — a estatística local de pitch/classe é saturável em ~1 compasso.
4. **`TRACK_SELECT`** deve piorar pouco em CE agregada, mas a *coerência cross-track* (medida à parte) deve degradar muito em 256.

Se a estratificação mostrar que **todo** o gap está em `TIME_SHIFT` + boundary e nada em `NOTE` mid-window, a conclusão correta não é "preciso de janela maior" — é "preciso de **codificação temporal mais densa**" (bar/beat tokens, deltas maiores). Isso é acionável e é o tipo de resultado que justifica o ablation.

### Controle de crop

Janelas devem ser cortadas em fronteiras de evento (`TIME_SHIFT`/`TRACK_SELECT`), não em posição aleatória, senão o 256 gera mais continuações "impossíveis" (ex.: janela começando num `NOTE` sem onset) e infla CE por artefato. Fixe a seed de crop entre runs.

---

## 3. Velocidade de convergência

Com orçamento fixo em tokens (recomendado):

- **256 converge mais rápido por token** (4× mais passos, gradiente mais frequente) e atinge seu platô em ~1/3 do wall-clock do 1024. Mas **platô mais alto** em CE agregada e muito pior em métricas de longo alcance.
- **1024 tem early convergence mais lenta** (menos passos por token, maior variância por passo) mas assíntota melhor. É o padrão clássico de "contexto maior = mais lento para treinar, melhor teto".
- **Risco de overfitting no 256:** com lr=3e-4 fixo e 4× mais passos, o 256 pode começar a overfittar padrões locais antes do fim do orçamento — monitore train/val gap por run; pode ser necessário early stopping *diferente por run*, o que reintroduz confound. Alternativa: reportar curva completa (CE vs tokens) em vez de ponto final.
- **lr=3e-4** provavelmente é ótimo para 1024 e levemente alto para 256 com muitos passos; se quiser rigor, faça um mini-sweep de lr *por block_size* em run separada e reporte os dois (fixed-lr como principal, lr-ótimo como apêndice).

---

## 4. O que muda qualitativamente (o que cada janela *pode* aprender)

**256 (~1,5 compasso, ~6 notas de histórico por trilha):**
- Aprende estatística local: classes de altura por instrumento, durações típicas, densidade rítmica, co-ocorrência de notas simultâneas entre 2–3 trilhas.
- **Não pode** aprender: repetição de motivo além de ~6 notas, progressão harmônica de 4 compassos, call-response entre trilhas com defasagem de 1 compasso, cadências, forma.
- Patologias de geração esperadas: *loops* locais (repetição de 1 compasso), drift de tonalidade, trilhas que "esquecem" que tocaram (silêncio > 1,5 compasso apaga o contexto da trilha), sincronização cross-track frágil. O Constrained Decoder mascara sintaxe (notas válidas), **não** mascara falta de estrutura — os artefatos vão aparecer como música sintaticamente correta e musicalmente incoerente.

**512:** capta motivos de 2–4 compassos, progressões simples, alguma imitação cross-track.

**1024:** capta frases, repetição de seção, motivos compartilhados entre trilhas. Ainda falha além de ~6–7 compassos.

**Ponto crítico de train/inference mismatch:** o PE é `nn.Embedding(block_size, d_model)` — **cap duro**. Um modelo treinado em 256 **não pode** gerar além de 256 tokens sem rolling window, e nunca viu posições >256. Se a geração usar janela deslizante maior que o treino, o PE quebra; se usar 256, a coerência de longo prazo é estruturalmente impossível. Esse é o argumento mais forte para, no ablation, também registrar geração com a *mesma* janela de treino e medir degradação ao longo do tempo gerado.

---

## 5. O que acontece com a atenção causal a 256

Mecânica concreta, dado que ~3 s enchem a janela:

**(a) Contexto efetivo médio triangular.** Com máscara causal, a query na posição *i* vê *i* tokens. Média = 128 no 256, 512 no 1024. Como a loss é média por token, **os primeiros tokens (com pouco contexto) pesam proporcionalmente 4× mais** no 256. A "rampa" de contexto domina a CE agregada de forma que não reflete capacidade de modelagem de longo alcance.

**(b) Campo receptivo em tempo musical, não em tokens.** A distância máxima de atenção é o span da janela: **~3,2 s no 256**. Nenhuma cabeça pode implementar "igual a 2 compassos atrás" — essa posição simplesmente não existe no grafo de atenção. Heads vão especializar em: proximidade posicional, onset coincidente, mesma trilha recente, vizinhança de `TRACK_SELECT`. Heads "globais" (que em 1024 poderiam rastrear motivo) não têm o que rastrear em 256.

**(c) Atenção cross-track fácil, cross-tempo impossível.** Tokens recentes de outras trilhas estão a ≤25 posições, então atenção inter-trilha *local* é barata. Mas se uma trilha fica em silêncio por 1 compasso (200 ticks > 256 posições), seu histórico sai da janela: o modelo não pode condicionar na última nota dela. Isso produz o artefato de "trilha que reaparece sem continuidade".

**(d) Distribuições de atenção mais agudas e menos diversas.** Softmax sobre ~128 tokens médios vs 512 → menor entropia, maior variância; com 8 heads e d_head=32, heads tendem a colapsar em padrões locais similares. Meça **entropia de atenção e distância média de atenção em tempo musical** por camada/head: em 256 espero entropia menor, distância em tokens similar, mas **distância em tempo musical comprimida** — é a assinatura do gargalo.

**(e) Boundary contamination.** LayerNorm pre-norm + causal: os primeiros tokens funcionam como *attention sink*. Em 256 a região de sink é fração maior da sequência; o modelo aprende a "reiniciar" contexto a cada janela, o que é um viés indutivo errado para música contínua. Se você fizer chunking com sobreposição e loss mascarada nos tokens de contexto, remove parte desse viés — mas aí o ablation deixa de isolar só `block_size`.

**(f) Custo.** Atenção O(L²): 256 é 16× mais barato por sequência que 1024. É o que permite 4× mais passos no mesmo orçamento de tokens — e é exatamente por isso que o confound do §1 precisa ser controlado explicitamente.

---

## 6. Protocolo mínimo para o resultado ser interpretável

1. **Orçamento em tokens vistos**, schedule de LR em tokens, batch em tokens.
2. **CE estratificada** por tipo de token (`TIME_SHIFT`/`NOTE`/`VELOCITY`/`TRACK_SELECT`) e por posição na janela (buckets 0–10, 10–30, 30+). Predição falsificável do §2.
3. **Curva CE vs tokens** (não só ponto final) para separar "converge rápido" de "platô melhor".
4. **Diagnósticos de atenção:** entropia, distância média em *tempo musical*, fração de atenção same-track (segmentando por `TRACK_SELECT`).
5. **Métricas musicais de longo prazo** além de CE: taxa de repetição motívica, auto-similaridade por compasso, coincidência de onsets cross-track, distância de histograma de classes de altura vs treino, coerência em gerações de 30 s com rolling window.
6. **Regra de decisão pré-registrada:** se ΔCE(256,1024) < ~0,1 nat e métricas musicais não diferem → longo alcance não é o gargalo; o problema é codificação temporal (vá para bar/beat tokens). Se ΔCE > 0,3 nat concentrado em `TIME_SHIFT`/boundary → o gargalo é densidade temporal e boundary, não capacidade de atenção; janela maior sozinha não resolve. Se ΔCE > 0,3 nat concentrado em `NOTE` mid-window e métricas de motivo → aí sim `block_size` é o gargalo real e justifica RoPE/ALiBi para desacoplar janela de treino da de inferência.


---
